from flask import Flask, render_template, request 
from reader import *
from datasets import *
app= Flask(__name__)



@app.route("/")
def homepage():
    ''' this is the main page, it contains links to other destinations and information about the web interface.
        Shows the first 200 entries of the dataset, converted to an html table in the "table" variable '''
    
    #extract a subset of initial 200 entries
    sample=data.df.iloc[:200, :]

    #create table
    table= sample.to_html()
    return render_template("Homepage.html", table= table)


@app.route("/Active_Operations")
def active_operations():
    '''This is the page where all the active operations can be found. It contain a conversion dictionary that allows to show a string as the name for the operation on the web page.
        It checks the register of active operations, then shows a menu containing the string corresponding to the operations in the register.
        When an operation is chosen, the user is automatically redirected to the page "Operation" and a value is sent to this page specifying which operation has to be performed. '''
    
    #dictionary containing operation names to visualize in the web page 
    names= {"get_columns": "Get Columns", "get_ID": "Get Unique ID", "get_type": "Get Unique Type", "count_entries": "Get Number of Entries for Type", "get_chromosomes": "Get Whole Chromosome Dataset", "count_fragmented": "Get Fraction of Fragmented Features" , "get_ens_hav": "Get Ensembl-Havana Dataset", "count_ens_hav":"Count Entries in Ensembl-Havana Dataset:", "get_gene_names":"Get Genes Names" }
    
    #access active operations 
    menu_values= Operation._get_register()
    
    #create a new dictionary containing the subset of active operations previously obtained 
    active_op= { i: names[i] for i in menu_values}
   
    return render_template("Active_Operations.html", active_op= active_op )


@app.route("/Operation")
def operation():
    '''This page is responsible for performing the chosen operation, it requests the 'value' passed from the active operation page and performs the corresponding operation accordingly. It then prints the result of the operation.
        The variable table_templ is set to False by default. In this case the result will be directly shown, in case the result of the operation was another dataFrame, table_templ takes value True and the result will be coverted to an html table with a maximum of 2000 rows '''
    
    #dictionary storing the possible passed values and the corresponding operation object 
    op_dict= {"get_columns": get_columns(), "get_ID": get_ID(),  "get_type": get_type(), "count_entries": count_entries(), "get_chromosomes": get_chromosomes(), "count_fragmented": count_fragmented() , "get_ens_hav": get_ens_hav(), "count_ens_hav": count_ens_hav(), "get_gene_names":get_gene_names() }
    
    #ask for passed value 
    op_type=request.args.get('value') 
    
    #take corresponding operation 
    if op_type in op_dict.keys(): 
        operator= op_dict[op_type]
    else:
        return "Operation not found"
    
    #perform operation and store result 
    result= operator.run(data).show_result()
    
    table_templ= False
    #if the result is a dataframe, instead of returning the result of the operation, returns the html format of the dataframe table, which will be directly read by jinja as html code. 
    if isinstance(result, pd.DataFrame):
        result = result.to_html(max_rows=2000)
        table_templ= True
        
    

    return render_template("Operation.html", result= result, table_templ= table_templ )

@app.route("/Documentation")
def documentation():
    '''This page simply contains the documentation for the developement of the project. '''
    
    return render_template("Documentation.html")



if __name__== "__main__":
    app.run()
